package com.fil.crm.paas.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fil.crm.paas.constants.QueryConstants;
import com.fil.crm.paas.domain.AuditData;
import com.fil.crm.paas.domain.InvestmentAccount;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.vo.EmailConfig;

/**
 *
 * @author Arvind Singh
 *
 */
@Repository
public class InvestmentAccountDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvestmentAccountDAO.class);

	@Autowired
	private JdbcTemplate jdbcTemplateCRDB;

	public List < InvestmentAccount > getInvestmentAccounts(int offset, int limit) throws DatabaseException {
		List < InvestmentAccount > investmentAccountsList = null;
		Long start = System.currentTimeMillis();
		try {
			investmentAccountsList = jdbcTemplateCRDB.query((PreparedStatementCreator) conn -> {
				PreparedStatement pst = conn.prepareStatement(QueryConstants.SELECT_INVESTMENT_ACCOUNT_DATA);
				pst.setLong(1, offset);
				pst.setLong(2, limit);
				return pst;
			}, (RowMapper < InvestmentAccount >) (rs, rownum) -> {
				InvestmentAccount investmentAccount = new InvestmentAccount();
				investmentAccount.setCurrency(rs.getString(QueryConstants.CURRENCY));
				investmentAccount.setEffectiveDate(rs.getString(QueryConstants.EFFECTIVE_DATE));
				investmentAccount.setFundCode(rs.getString(QueryConstants.FUND_CODE));
				investmentAccount.setFundValue(rs.getString(QueryConstants.FUND_VALUE));
				investmentAccount.setSeqId(rs.getString(QueryConstants.SEQ_ID));
				investmentAccount.setSourceType(rs.getString(QueryConstants.SOURCE_TYPE));
				//				investmentAccount.setAccountStatus(rs.getString(QueryConstants.ACCOUNT_STATUS));
				//				investmentAccount.setAccountInfo(rs.getString(QueryConstants.ACCOUNT_INFO));
				return investmentAccount;
			});
		} catch (Exception ex) {
			throw new DatabaseException("Error occured while fetching the data from CRDB database", ex);
		}
		Long end = System.currentTimeMillis();
		LOGGER.info("Time taken :: " + (end - start));
		return investmentAccountsList;
	}

	public long saveAudit(final AuditData auditData) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		int rows = jdbcTemplateCRDB.update((PreparedStatementCreator) conn -> {
			PreparedStatement pst = conn.prepareStatement(QueryConstants.INSERT_INVESTMENT_ACCOUNT_AUDIT_DATA, new String[] { "id" });
			pst.setString(1, auditData.getCorrelationId());
			pst.setTimestamp(2, new Timestamp(auditData.getStartTime()));
			pst.setTimestamp(3, new Timestamp(auditData.getEndTime()));
			pst.setString(4, auditData.getResponseJson());
			pst.setString(5, auditData.getStatus());
			pst.setString(6, auditData.getErrorReason());
			pst.setString(7, auditData.getUserName());
			return pst;
		}, keyHolder);
		if (rows > 0) {
			return keyHolder.getKey().longValue();
		} else {
			return -1;
		}
	}

	public Long getCount() throws DatabaseException {
		long count = 0;
		try {
			count = jdbcTemplateCRDB.queryForObject(QueryConstants.SELECT_COUNT_INVESTMENT_ACCOUNT_DATA, Long.class);
		} catch (DataAccessException e) {
			throw new DatabaseException(e.toString(), e);
		}
		return count;
	}

	/**
	 * This method is used fetch the config values from CRDB.
	 *
	 * @param paramName
	 * @return
	 */
	public String getConfigVar(String paramName) throws DatabaseException {
		String paramValue = null;
		try {
			paramValue = jdbcTemplateCRDB.query(QueryConstants.SELECT_CONFIG_DATA, new Object[] { paramName },
					(ResultSetExtractor < String >) rs -> {
						if (rs.next()) {
							return rs.getString("PARAM_VALUE");
						} else {
							LOGGER.error("N config var not found for Param Name [{}]", paramName);
							return null;
						}
					});
		} catch (Exception e) {
			throw new DatabaseException(e.toString(), e);
		}
		return paramValue;
	}

	/**
	 * This method will get all the config variables for Email template
	 *
	 * @return
	 * @throws DatabaseExceptio
	 *
	 */
	public EmailConfig getEmailConfig() throws DatabaseException {
		try {
			return jdbcTemplateCRDB.query(QueryConstants.SELECT_EMAIL_CONFIG_DATA, new MyExtractor());
		} catch (DataAccessException e) {
			throw new DatabaseException(e.toString(), e);
		}
	}

	static class MyExtractor implements ResultSetExtractor < EmailConfig > {

		@Override
		public EmailConfig extractData(ResultSet rs) throws SQLException {
			EmailConfig emailConfigVars = new EmailConfig();
			while (rs.next()) {
				if (rs.getString(QueryConstants.PARAM_NAME).equals(QueryConstants.FROM_EMAIL_ADDRESS)) {
					emailConfigVars.setFromEmailAddress(rs.getString(QueryConstants.PARAM_VALUE));
				} else {
					setEmailConfigValues(rs, emailConfigVars);
				}
			}
			return emailConfigVars;
		}

		private void setEmailConfigValues(ResultSet rs, EmailConfig emailConfigVars) throws SQLException {
			switch (rs.getString(QueryConstants.PARAM_NAME)) {
			case QueryConstants.FROM_EMAIL_ADDRESS:
				emailConfigVars.setFromEmailAddress(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			case QueryConstants.TO_EMAIL_ADDRESS:
				emailConfigVars.setToEmailAddress(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			case QueryConstants.EMAIL_HOST:
				emailConfigVars.setEmailHost(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			case QueryConstants.EMAIL_SERVER:
				emailConfigVars.setEmailServer(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			case QueryConstants.EMAIL_ENABLE:
				emailConfigVars.setEnableEmail(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			case QueryConstants.EMAIL_SUBJECT:
				emailConfigVars.setSubject(rs.getString(QueryConstants.PARAM_VALUE));
				break;
			default:
			}
		}
	}
}
