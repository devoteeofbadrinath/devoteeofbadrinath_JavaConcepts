package com.fil.inst.ukpi.conversion;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fil.inst.ukpi.constants.CommonConstants;
import com.fil.inst.ukpi.conversion.model.SalesforceResponse;
import com.fil.inst.ukpi.sftp.FftsService;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FileConversion {

	@Autowired
	private FftsService fftsService;
	
	
	
	@Value("${ffts.location}")
	private String remoteLocation;
	
	public void conversionDynamicallys(List<Map<String, String>> objmap,String sheetName) 
			throws IOException, IllegalArgumentException, IllegalAccessException, SftpException,
			InterruptedException {
		log.info("[{}] :: File conversion is started for the file "+ sheetName);	
		
		
		XSSFRow row = null;
		Field[] fields = null;
		Field[] fieldCell = null;
		FileOutputStream out = null;
		try (XSSFWorkbook workbook = new XSSFWorkbook()){

		
		XSSFSheet spreadsheet = workbook.createSheet(sheetName);
		
		int rowid = 0;
		int cellid = 0;
		row = spreadsheet.createRow(0);
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		fields = salesforceResponse.getClass().getDeclaredFields();
		for(Field f : fields) {
			f.setAccessible(true);
			row.createCell(rowid++).setCellValue(f.getName());
		}
		log.info("[{}] :: Headers are created successfully ");
		int lastRowCount = spreadsheet.getLastRowNum();
		int i = 0;
		while(i < objmap.size()) {
			Map<String,String> map = objmap.get(i);
			salesforceResponse = null;
			salesforceResponse = readFields(map);
			List<String> valueObjs = new ArrayList<String>();
			objmap.get(i).forEach((key,value)->{
				valueObjs.add(value);
			});
			row = spreadsheet.createRow(++lastRowCount);
			fieldCell = salesforceResponse.getClass().getDeclaredFields();
			for (Field obj : fieldCell) {
				obj.setAccessible(true);
				row.createCell(cellid++).setCellValue((String)obj.get(salesforceResponse));

			}
			cellid = 0;
			i++;
		}
	
		log.info("[{}] :: total rows created "+i);
		String ukpiFile = filename(sheetName);
		File file = new File(System.getProperty("user.dir")+"\\src\\test\\resources\\"+ukpiFile);
		out = new FileOutputStream(file);
		workbook.write(out);
		workbook.close();
		out.close();
		log.info("Path of files "+file.getAbsolutePath()+" is exist "+file.exists());
		fftsService.fftsConnection(file, ukpiFile);

		}
		catch(Exception e) {
			log.error(e.getMessage());
		}
		
	}
	
	public static SalesforceResponse readFields(Map<String,String> map) throws IllegalArgumentException,
	IllegalAccessException {
		SalesforceResponse salesforceResponse = new SalesforceResponse();
		Field[] fields = salesforceResponse.getClass().getDeclaredFields();
		map.forEach((key,value)->{
		});
		for(Field f : fields) {
			f.setAccessible(true);
			f.set(salesforceResponse, map.get(f.getName()));
		}
		return salesforceResponse;
	}
	
	public String filename(String filename) {
		
		SimpleDateFormat date = new SimpleDateFormat("ddMMyy");
		Date today = new Date();
		String str = date.format(today)+".xlsx";
		
		Map<String,String> map = new HashMap<String,String>();
		map.put(CommonConstants.INVESTMENT_ADVICE,CommonConstants.FILE_NAME+"InvestmentAdvice_"+str);
		map.put(CommonConstants.SPECIALIST_ADVICE,CommonConstants.FILE_NAME+"SpecialistAdvice_"+str);
		map.put(CommonConstants.INVESTMENT_GUIDANCE,CommonConstants.FILE_NAME+"InvestmentGuidance_"+str);
		map.put(CommonConstants.PICC,CommonConstants.FILE_NAME+"PICC_"+str);
		map.put(CommonConstants.LIC,CommonConstants.FILE_NAME+"LICWalkIn_"+str);
		map.put(CommonConstants.WI_PI,CommonConstants.FILE_NAME+"WI_PI_investmentguidance_"+str);
		
		return map.get(filename);
	}
	

}
