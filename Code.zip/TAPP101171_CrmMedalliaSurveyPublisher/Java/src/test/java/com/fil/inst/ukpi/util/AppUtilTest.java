package com.fil.inst.ukpi.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.fil.inst.ukpi.scheduler.quartz.configuration.AppUtil;

@RunWith(MockitoJUnitRunner.class)
public class AppUtilTest {


	@InjectMocks
	private AppUtil app;
	
	@Test
	public void getUUID() {
		Assert.assertNotNull(AppUtil.getUUID());
	}
	
	@Test
	public void getTransactionId() {
		Assert.assertNotNull(AppUtil.getTransactionId());
	}
	
	@Test
	public void isObjectEmpty() {
		Assert.assertNotNull(AppUtil.isObjectEmpty(new Object()));
	}
	@Test
	public void isObjectEmpty1() {
		Assert.assertNotNull(AppUtil.isObjectEmpty(null));
	}
	@Test
	public void isObjectEmpty2() {
		Assert.assertNotNull(AppUtil.isObjectEmpty("test"));
	}
	
	@Test
	public void concatenate() {
		List < String > listOfItems = new ArrayList<String>();
		listOfItems.add("test");
		listOfItems.add("test 1");
		String separator = ",";
		app.concatenate(listOfItems, separator);
		Assert.assertNotNull(app);
	}
}
