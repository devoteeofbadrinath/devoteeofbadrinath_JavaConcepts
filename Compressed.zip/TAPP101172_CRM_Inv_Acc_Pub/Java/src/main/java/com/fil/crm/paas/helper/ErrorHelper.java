package com.fil.crm.paas.helper;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import com.fil.crm.paas.enums.STATUS;
import com.fil.crm.paas.exception.ServiceException;
import com.google.gson.JsonObject;

/**
 * 
 * @author Arvind Singh
 *
 */
public final class ErrorHelper {

	private static final String status = "status";

	private static final String MESSAGE = "message";

	private static JsonObject validationRespObj = new JsonObject();

	private static JsonObject respObj = new JsonObject();
	static {
		// validation error
		validationRespObj.addProperty(status, HttpStatus.BAD_REQUEST.value());
		validationRespObj.addProperty(MESSAGE, HttpStatus.BAD_REQUEST.getReasonPhrase());
		// any other error
		respObj.addProperty(MESSAGE, HttpStatus.SERVICE_UNAVAILABLE.value());
		respObj.addProperty(status, HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
	}

	private ErrorHelper() {
	}

	public static void handleException(RestClientException e) throws ServiceException, JSONException {
		JSONObject response = new JSONObject();
		if (e instanceof HttpStatusCodeException) {
			if (!StringUtils.isEmpty(((HttpStatusCodeException) e).getResponseBodyAsString())) {
				response = new JSONObject(((HttpStatusCodeException) e).getResponseBodyAsString());
			} else {
				response.put(MESSAGE, ((HttpStatusCodeException) e).getStatusText());
			}
		} else {
			response.put(MESSAGE, e.getMessage());
		}
		throw new ServiceException(STATUS.INTERNAL_SERVER_ERROR, "Error from GDS token validator : " + response.getString(MESSAGE), e);
	}
}
