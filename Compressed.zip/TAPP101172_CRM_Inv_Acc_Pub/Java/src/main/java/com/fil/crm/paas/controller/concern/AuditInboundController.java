package com.fil.crm.paas.controller.concern;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fil.crm.paas.constants.JsonMappingConstants;
import com.fil.crm.paas.dao.InvestmentAccountDAO;
import com.fil.crm.paas.domain.AuditData;
import com.google.gson.JsonObject;

@Aspect
@Component
public class AuditInboundController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuditInboundController.class);

	@Autowired
	private InvestmentAccountDAO investmentAccountDAO;

	private AuditData auditData;

	@Pointcut("execution(* com.fil.crm.paas.service.InvestmentAccountService.pushInvestmentAccounts(java.lang.String))")
	public void methodPointcut() {
	}

	@AfterReturning(pointcut = "methodPointcut()", returning = "jsonObject")
	public void afterControllerpushToLayer7(JsonObject jsonObject) {
		try {
			if (jsonObject.has(JsonMappingConstants.RESULT) && getResult(jsonObject)) {
				auditData = new AuditData();
				auditData.setEndTime(System.currentTimeMillis());
				auditData.setStatus(JsonMappingConstants.SUCCESS);
				auditData.setStartTime(jsonObject.has(JsonMappingConstants.START_TIME)
						? jsonObject.get(JsonMappingConstants.START_TIME).getAsLong() : -1L);
				auditData.setCorrelationId(jsonObject.has(JsonMappingConstants.CORRELATION_ID)
						? jsonObject.get(JsonMappingConstants.CORRELATION_ID).getAsString() : "");
				auditData.setUserName(getUserName(jsonObject));
				auditData.setResponseJson(jsonObject.toString());
				investmentAccountDAO.saveAudit(auditData);
			}
		} catch (Exception e) {
			LOGGER.error("AUDITING FAILED :: " + e.toString());
		}
	}

	private String getUserName(JsonObject jsonObject) {
		return jsonObject.has(JsonMappingConstants.USER_NAME) ? jsonObject.get(JsonMappingConstants.USER_NAME).getAsString() : "";
	}

	private boolean getResult(JsonObject jsonObject) {
		return JsonMappingConstants.SUCCESS.equalsIgnoreCase(jsonObject.get(JsonMappingConstants.RESULT).getAsString());
	}
}