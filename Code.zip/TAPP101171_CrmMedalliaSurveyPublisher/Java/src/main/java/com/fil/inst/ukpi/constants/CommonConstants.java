package com.fil.inst.ukpi.constants;

public class CommonConstants {

	
	public static int COUNT = 0;
	
	public static final Integer MINIMUMIDLE = 5;
	
	public static final Integer MAXIMUMPOOLSIZE = 10;
	
	public static final Integer MAXLIFETIME = 600000;
	
	public static final Integer THREADSLEEP = 600000;
	
	public static final Integer CONNECTIONTIMEOUT = 180000;
	
	public static final String MODIFIEd_DATE = "modifieddate";
	
	public static final String TRACKING_ID = "TRACKING_ID";

	public static final String NO_DC_MAIL_MSG = "Scheduler execution completed successfully for all records.";

	public static final String ACCESS_TOKEN = "access_token";

	public static final String INSTANCE_URL = "instance_url";

	public static final String ID = "id";

	public static final String TOKEN_TYPE = "token_type";

	public static final String ISSUED_AT = "issued_at";

	public static final String UKPI = "ukpi";

	public static final String SALESFORCE = "tosalesforce";

	public static final String SIGNATURE = "signature";

	public static final String END_POINT = "/services/apexrest/FIL_UKPIInvitee/sidinvitee/investment-guidance";

	public static final String SHEETNAME = "Investment-guidance";

	public static final String INVESTMENT_GUIDANCE = "investment-guidance";

	public static final String INVESTMENT_ADVICE = "investment-advice";

	public static final String SPECIALIST_ADVICE = "specialist-advice";

	public static final String PICC = "picc";

	public static final String LIC = "lic-walkin";
	
	public static final String WI_PI = "wipi";

	public static final String FILE_NAME = "fidelityinternational_invite_file_UKPI_";

	public static final String CRON_EXPRESSION = "CRON_JOB_EXPRESSION";

	public static final String JDBC_URL = "spring_datasource_url";

	public static final String DS_USER_NAME = "spring_datasource_username";

	public static final String DS_CONNECTION_POOL_NAME = "springHikariCP";

	public static final String DS_CACHE_PREPARE_STATMENT = "dataSource.cachePrepStmts";

	public static final String DS_PREPARE_STATMENT_CACHE_SIZE = "dataSource.prepStmtCacheSize";

	public static final String DS_PREPARE_STATMENT_CACHE_SQL_LIMIT = "dataSource.prepStmtCacheSqlLimit";

	public static final String DS_USE_SERVER_PREPARE_STATMENT = "dataSource.useServerPrepStmts";

	public static final String DB_CONNECTION_TEST_QUERY = "select sysdate from dual";

	public static final String DS_DRIVER_CLASS_NAME = "spring.datasource.driver-class-name";

	public static final String FAILURE_MSG = "Error while sending email for blocked jobs";
	
	public static final String P_PREFIX = "{noop}";

	public static final String EMPTY_STRING = "";

}
