package com.fil.inst.ukpi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import io.pivotal.cfenv.core.CfEnv;


@SpringBootApplication(scanBasePackages = { "com.fil.inst.ukpi" },exclude={DataSourceAutoConfiguration.class})

@EnableTransactionManagement
@EnableScheduling
@EnableRetry
public class AutomationUkpisurveyApplication extends SpringBootServletInitializer {


	
	public static void main(String[] args) {
		
		SpringApplication.run(AutomationUkpisurveyApplication.class, args);

	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		
		return application.sources(AutomationUkpisurveyApplication.class);
	}
	
	@Bean
	public CfEnv cfEnv() {
		
		return new CfEnv();
	}

}
