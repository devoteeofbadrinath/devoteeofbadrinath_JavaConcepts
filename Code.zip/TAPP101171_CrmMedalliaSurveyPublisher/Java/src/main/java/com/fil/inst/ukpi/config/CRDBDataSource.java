package com.fil.inst.ukpi.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;

import com.fil.inst.ukpi.constants.CommonConstants;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class CRDBDataSource {


	@Bean(destroyMethod = "close")
	@Primary
	public DataSource dataSource(@Autowired
			@Lazy Environment env) {
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(env.getProperty(CommonConstants.DS_DRIVER_CLASS_NAME));
		hikariConfig.setJdbcUrl(env.getProperty(CommonConstants.JDBC_URL));
		hikariConfig.setUsername(env.getProperty(CommonConstants.DS_USER_NAME));
		hikariConfig.setPassword(env.getProperty("spring_datasource_password"));
		hikariConfig.setMinimumIdle(CommonConstants.MINIMUMIDLE);
		hikariConfig.setMaximumPoolSize(CommonConstants.MAXIMUMPOOLSIZE);
		hikariConfig.setMaxLifetime(CommonConstants.MAXLIFETIME);
		hikariConfig.setConnectionTimeout(CommonConstants.CONNECTIONTIMEOUT);
		hikariConfig.setPoolName(CommonConstants.DS_CONNECTION_POOL_NAME);
		hikariConfig.addDataSourceProperty(CommonConstants.DS_CACHE_PREPARE_STATMENT, "true");
		hikariConfig.addDataSourceProperty(CommonConstants.DS_PREPARE_STATMENT_CACHE_SIZE, "250");
		hikariConfig.addDataSourceProperty(CommonConstants.DS_PREPARE_STATMENT_CACHE_SQL_LIMIT, "2048");
		hikariConfig.addDataSourceProperty(CommonConstants.DS_USE_SERVER_PREPARE_STATMENT, "true");
		hikariConfig.setConnectionTestQuery(CommonConstants.DB_CONNECTION_TEST_QUERY);
		HikariDataSource dataSource = new HikariDataSource(hikariConfig);
		log.debug("Data source connected succesfully");
		return dataSource;
	}



}
