package com.fil.inst.ukpi.serviceImp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.service.spi.ServiceException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fil.inst.ukpi.constants.CommonConstants;
import com.fil.inst.ukpi.conversion.FileConversion;
import com.fil.inst.ukpi.conversion.model.TokenResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FilesbyCreatedDate {


	@Value("${grant_type}")
	private String grant;

	@Value("${client_id}")
	private String client_id;

	@Value("${client_secret}")
	private String client_secret;

	@Value("${salesforceUrl}")
	private String commonUri;

	@Value("${inbound.layer7VOC}")
	private String voc;

	@Value("${constantUri}")
	private String sfEndpoint;

	@Value("${inbound.layer7}")
	private String layer7Url;
	
	@Value("${salesforce.file}")
	private String listOfendpoints;
	
	@Value("${layer7.auth}")
	private String token;
	

	@Autowired
	private FileConversion fileConversion;
	
	
	public void getTokenFromSfByDate(String createddate) throws Exception {
		
		log.info("get token and instance url from salesforce Starts");
		TokenResponse tokenResponse = new TokenResponse();
		try {
			JSONObject json = callLayer7forTokenDate();
			tokenResponse.setAcccess_token(json.getString(CommonConstants.ACCESS_TOKEN));
			tokenResponse.setId(json.getString(CommonConstants.ID));
			tokenResponse.setInstance_url(json.getString(CommonConstants.INSTANCE_URL));
			tokenResponse.setIssue_at(json.getString(CommonConstants.ISSUED_AT));
			tokenResponse.setSignature(json.getString(CommonConstants.SIGNATURE));
			tokenResponse.setToken_type(json.getString(CommonConstants.TOKEN_TYPE));
			log.info("Token, instance url retrive successfully from Salesforce ");
			log.info("RestTemplate method is stared to get VOC data from salesforce");
			List<String> endpoint = listOfEndPoint();
			
			for (String end_point : endpoint) {
				callResttemplateDate(tokenResponse.getAcccess_token(),
						tokenResponse.getInstance_url(), end_point, createddate);
			}

			
		} catch (IOException e) {
			log.error(e.getMessage());;
		}
	}
	
	public JSONObject callLayer7forTokenDate() throws ServiceException{
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("grant_type", grant);
		headers.set("client_id", client_id);
		headers.set("client_secret", client_secret);
		headers.set("salesforceUrl", commonUri);
		headers.set("apikey", token);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
 
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = null;
		try {
		response = restTemplate.exchange(layer7Url, HttpMethod.POST, entity, String.class);
		JSONObject json = new JSONObject(response.getBody());
		return json;
		}
		catch(HttpClientErrorException | HttpServerErrorException e) {			
			log.error("Error Occured during getting token and Instance URL from Salseforce "+e.getMessage());
		}
		return null;
		
	}
	
	public void callResttemplateDate(String accessToken, String instanceUrl, String endpoint,String createddate)
			throws Exception {
		log.info("Authentication is done successfully ");
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = setHeaders(accessToken, instanceUrl, endpoint, createddate);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		Map<String,String> param = new HashMap<String,String>();
		param.put("createddate", createddate);
		log.info("Salesforce Api calling started with endpoint " + endpoint);
		ResponseEntity<String> response = restTemplate.exchange(voc, HttpMethod.GET, entity, String.class,param);		
		log.info("Salesforce Api executed successfully");
		log.info(endpoint);
		String parse = response.getBody();
		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, String>> map = mapper.readValue(parse, new TypeReference<List<Map<String, Object>>>() {
		});
		if (!map.isEmpty())
		{
			fileConversion.conversionDynamicallys(map, endpoint);
		}
		else {
			log.info("No data found with this endpoint " + endpoint);
		}
		
	}
	
	public HttpHeaders setHeaders(String accessToken, String instanceUrl, String endpoint,String createddate) {

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + accessToken);
		headers.set("instance_url", instanceUrl + sfEndpoint + endpoint);
		headers.set("apikey", token);
		headers.set("createddate", createddate);
		headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return headers;
	}
	
	public ArrayList<String> listOfEndPoint(){
		String[] files = listOfendpoints.split(";");
		ArrayList<String> endpoint = new ArrayList<String>();
		
		for(String file : files) {
		endpoint.add(file);
		}
		return endpoint;
	}
	
}
