package com.fil.crm.paas.constants;

/**
 *
 * @author Arvind Singh
 *
 */
public class QueryConstants {

	//	public static final String SELECT_INVESTMENT_ACCOUNT_DATA = "SELECT CURRENCY, EFFECTIVE_DATE, FUND_CODE, FUND_VALUE, SEQ_ID, SOURCE_TYPE, ACCOUNT_STATUS, ACCOUNT_INFO FROM vw_fund_tna where SEQ_ID>=? AND SEQ_ID <=?";
	public static final String SELECT_INVESTMENT_ACCOUNT_DATA = "SELECT CURRENCY, EFFECTIVE_DATE, FUND_CODE, FUND_VALUE, SEQ_ID, SOURCE_TYPE  FROM vw_fund_tna where SEQ_ID>=? AND SEQ_ID <=?";
  
   // public static final String SELECT_INVESTMENT_ACCOUNT_DATA = "SELECT CURRENCY, EFFECTIVE_DATE, FUND_CODE, FUND_VALUE, SEQ_ID, SOURCE_TYPE  FROM vw_fund_tna where EFFECTIVE_DATE = '26-NOV-2021'";

	public static final String INSERT_INVESTMENT_ACCOUNT_AUDIT_DATA = "INSERT INTO AUDIT_INVESTMENT_ACCOUNT (ID,CORRELATION_ID, TRANS_START_TIME, TRANS_END_TIME,TRANS_DATA,STATUS,ERR_REASON,USERNAME) "
			+ " VALUES (AUDIT_INVESTMENT_ACCOUNT_SEQ.NEXTVAL,? , ? , ?, ?, ?, ?,?)";

	public static final String SELECT_COUNT_INVESTMENT_ACCOUNT_DATA = "SELECT COUNT(1) FROM vw_fund_tna";

	public static final String FUND_CODE = "FUND_CODE";

	public static final String FUND_VALUE = "FUND_VALUE";

	public static final String CURRENCY = "CURRENCY";

	public static final String EFFECTIVE_DATE = "EFFECTIVE_DATE";

	public static final String SOURCE_TYPE = "SOURCE_TYPE";

	public static final String SEQ_ID = "SEQ_ID";

	public static final String GET_ROLES_QRY = " SELECT * FROM USER_ROLES WHERE LOWER(USERNAME) = LOWER(?) ";

	public static final String GET_USER_QRY = " SELECT * FROM USERS U WHERE LOWER(U.USERNAME) = LOWER(?) AND U.PASSWORD = ? ";

	public static final String CRON_JOB_EXPRESSION = "CRON_JOB_EXPRESSION";

	public static final String SELECT_EMAIL_CONFIG_DATA = "SELECT * FROM CONFIG_INVESTMENT_ACCOUNT";

	public static final String FROM_EMAIL_ADDRESS = "FROM_EMAIL_ADDRESS";

	public static final String TO_EMAIL_ADDRESS = "TO_EMAIL_ADDRESS";

	public static final String EMAIL_SUBJECT = "EMAIL_SUBJECT";

	public static final String EMAIL_HOST = "EMAIL_HOST";

	public static final String EMAIL_SERVER = "EMAIL_SERVER";

	public static final String EMAIL_ENABLE = "EMAIL_ENABLE";

	public static final String BATCH_SIZE = "BATCH_SIZE";

	public static final String SELECT_CONFIG_DATA = "SELECT PARAM_VALUE FROM CONFIG_INVESTMENT_ACCOUNT WHERE PARAM_NAME = ?";

	public static final String PARAM_VALUE = "PARAM_VALUE";

	public static final String PARAM_NAME = "PARAM_NAME";

	public static final String ACCOUNT_STATUS = "ACCOUNT_STATUS";

	public static final String ACCOUNT_INFO = "ACCOUNT_INFO";

	private QueryConstants() {
	}
}
