package com.fil.crm.paas.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.google.gson.JsonObject;

/**
 * 
 * @author Arvind Singh
 *
 */
@Component
public class JsonResponseValidator implements Validator {

	@Override
	public boolean supports(Class < ? > clazz) {
		return JsonObject.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		if (!(target instanceof JsonObject)) {
			return;
		}
	}
}
