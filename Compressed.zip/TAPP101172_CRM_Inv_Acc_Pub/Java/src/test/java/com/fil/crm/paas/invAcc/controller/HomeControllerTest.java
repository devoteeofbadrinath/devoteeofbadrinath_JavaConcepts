package com.fil.crm.paas.invAcc.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.fil.crm.paas.constants.JsonMappingConstants;
import com.fil.crm.paas.constants.RequestMappingContstants;
import com.fil.crm.paas.controller.HomeController;
import com.fil.crm.paas.enums.STATUS;
import com.fil.crm.paas.service.InvestmentAccountService;
import com.google.gson.JsonObject;

@RunWith(MockitoJUnitRunner.class)
public class HomeControllerTest {

	@InjectMocks
	private HomeController homeController;

	@Mock
	private InvestmentAccountService investmentAccountService;

	private MockMvc mockMvc;

	@Before
	public void init() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(homeController).setViewResolvers(resolver).build();
	}

	private JsonObject getJsonObject() {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(JsonMappingConstants.CORRELATION_ID, "1234567");
		jsonObject.addProperty(JsonMappingConstants.STATUS, STATUS.SUCCESS.getMessage());
		return jsonObject;
	}

	//	@Test
	//	public void healthCheckSuccessTest() throws Exception {
	//		Mockito.when(fxRatesService.getCount()).thenReturn(1L);
	//		this.mockMvc.perform(get("/")).andExpect(status().isOk());
	//	}
	//
	//	@Test
	//	public void healthCheck404Test() throws Exception {
	//		Mockito.when(fxRatesService.getCount()).thenReturn(1L);
	//		this.mockMvc.perform(get("/abc")).andExpect(status().isNotFound());
	//	}
	//
	//	@SuppressWarnings("unchecked")
	//	@Test
	//	public void healthCheckExceptionTest() throws Exception {
	//		Mockito.when(fxRatesService.getCount()).thenThrow(ServiceException.class);
	//		this.mockMvc.perform(get("/")).andExpect(status().isOk());
	//	}
	@Test
	public void adminPageTest() throws Exception {
		this.mockMvc.perform(get(RequestMappingContstants.ADMIN_URL)).andExpect(status().isOk());
	}

	@Test
	public void loginErrorMessageTest() throws Exception {
		this.mockMvc
				.perform(get(RequestMappingContstants.LOGIN).param(RequestMappingContstants.MODEL_ATTR_ERR,
						"UserName and password does not match"))
				.andExpect(model().attributeExists(RequestMappingContstants.MODEL_ATTR_ERR));
	}

	@Test
	public void logoutErrorMessageTest() throws Exception {
		this.mockMvc
				.perform(get(RequestMappingContstants.LOGIN).param(RequestMappingContstants.LOGOUT,
						"User has been logged " + "out successfully"))
				.andExpect(model().attributeExists(RequestMappingContstants.MODEL_ATTR_MSG))
				.andExpect(view().name(RequestMappingContstants.LOGIN_VIEW));
	}
}
