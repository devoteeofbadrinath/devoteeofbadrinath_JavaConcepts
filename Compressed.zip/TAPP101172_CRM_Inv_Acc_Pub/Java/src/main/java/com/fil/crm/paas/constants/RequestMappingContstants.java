package com.fil.crm.paas.constants;

/**
 * 
 * @author Arvind Singh
 *
 */
public class RequestMappingContstants {

	public static final String GET_JSON_FROM_ORG = "/getJsonFromOrg";

	public static final String SAVE_ENTITY = "/saveEntity";

	public static final String ROOT_API = "/api/";

	public static final String RESOURCES = "/resources/**";

	public static final String VIEWS = "/views/**";

	public static final String LOGIN = "/login";

	public static final String LOGIN_VIEW = "login";

	public static final String ADMIN_VIEW = "admin";

	public static final String ADMIN_URL = "/admin**";

	public static final String PUSH_TO_LAYER7 = "pushToLayer7";

	public static final String MODEL_ATTR_MSG = "msg";

	public static final String MODEL_ATTR_ERR = "error";

	public static final String LOGOUT = "logout";

	private RequestMappingContstants() {
	}
}
