package com.fil.crm.paas.constants;

/**
 *
 * @author Arvind Singh
 *
 */
public class JsonMappingConstants {

	public final static String DATA_SET_NAME = "DataSetName";

	public final static String CORRELATION_ID = "CorrelationId";

	public final static String USER_NAME = "userName";

	public final static String DATA = "Data";

	public final static String DATA_SET_NAME_VALUE = "AUM";

	public final static String RESULT = "result";

	public final static String SUCCESS = "SUCCESS";

	public final static String TRUE = "TRUE";

	public final static String FAIL = "FAIL";

	public final static String STATUS = "STATUS";

	public final static String CORRELATION_ID_IN_RESPONSE = "CorrelationId";

	public final static String START_TIME = "startTime";

	public final static String END_TIME = "endTime";

	public final static String AUM_AS_AT_DATE = "aumAsAtDate";

	public final static String IDENTIFIER = "identifier";

	public final static String IDENTIFIER_TYPE = "identifierType";

	public final static String AUM = "aum";

	public final static String AUM_ISO_CURRENCY_CODE = "aumIsoCurrencyCode";

	public final static String USERNAME = "userName";

	public static final String TIME_TAKEN = "timeTaken(Millis)";

	public static final String ACCOUNT_STATUS = "accountStatus";

	public static final String ACCOUNT_INFO = "accountInfo";

	private JsonMappingConstants() {
	}
}
