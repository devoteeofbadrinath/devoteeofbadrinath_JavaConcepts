package com.fil.crm.paas;

import java.net.InetSocketAddress;
import java.net.Proxy;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.client.RestTemplate;

/**
 * This the main class for Spring Boot. The application spring xml file will be
 * loaded in this class.
 *
 * @author Arvind Singh
 *
 */
@Configuration
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class })
//@ComponentScan(basePackages = { "com.fil.crm.paas" })
//The below packages are defined separately because System is reading class files in wrong order.
@ComponentScan(basePackages = { "com.fil.crm.paas.quartz.jobs", "com.fil.crm.paas.quartz.configuration", "com.fil.crm.paas" })
@PropertySource({ "classpath:application.properties" })
@SuppressWarnings("uncommentedmain")
public class Application {

	@Autowired
	DataSource dataSource;

	@Value("${fil.proxy.uk}")
	private String filproxy;

	@Value("${fil.proxy.uk.port}")
	private Integer port;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public JdbcTemplate jdbcTemplateCRDB() {
		return new JdbcTemplate(dataSource);
	}

	@Bean(name = "restTemplate")
	//@Profile("!prod")
	public RestTemplate restNonProdTemplate() {
		return new RestTemplate();
	}

	//@Bean(name = "restTemplate")
	//@Profile("prod")
	public RestTemplate restProdTemplate() {
		return new RestTemplate(requestFactory());
	}

	public ClientHttpRequestFactory requestFactory() {
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(filproxy, port));
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setProxy(proxy);
		requestFactory.setReadTimeout(120000);
		requestFactory.setConnectTimeout(120000);
		return requestFactory;
	}
}