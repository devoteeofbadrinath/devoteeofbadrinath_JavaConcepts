package com.fil.crm.paas.controller;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fil.crm.paas.constants.JsonMappingConstants;
import com.fil.crm.paas.constants.RequestMappingContstants;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.service.InvestmentAccountService;
import com.google.gson.JsonObject;

/**
 *
 * @author Arvind Singh
 *
 */
@Controller
@RequestMapping(value = RequestMappingContstants.ROOT_API)
public class InvestmentAccountController {

	private static final String INVESTMENT_ACCOUNT_ERROR_MSG = "Some exception has occured while pushing the CRDB data to Heroku.";

	private static final String INVESTMENT_ACCOUNT_SUCCESS_MSG = "CRDB Data have been successfully sent to Heroku.";

	@Autowired
	private InvestmentAccountService service;

	/**
	 * Thsi method will be called from admin page, Thsi will push data to Layer7
	 *
	 * @return ModelAndView
	 * @throws JSONException
	 * @throws DatabaseException
	 */
	@RequestMapping(value = "/pushToLayer7", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView pushToLayer7(HttpServletRequest request) throws JSONException {
		String userName = request.getUserPrincipal().getName();
		ModelAndView model = new ModelAndView();
		try {
			long startTime = System.currentTimeMillis();
			JsonObject respObj  = service.pushInvestmentAccounts(userName);
			long endTime = System.currentTimeMillis();
			respObj.addProperty(JsonMappingConstants.TIME_TAKEN, (endTime - startTime));
			model.setViewName(RequestMappingContstants.ADMIN_VIEW);
			if (respObj.has(JsonMappingConstants.STATUS)
					&& JsonMappingConstants.FAIL.equalsIgnoreCase(respObj.get(JsonMappingConstants.STATUS).getAsString())) {
				model.addObject(RequestMappingContstants.MODEL_ATTR_ERR, INVESTMENT_ACCOUNT_ERROR_MSG);
			} else {
				model.addObject(RequestMappingContstants.MODEL_ATTR_MSG, INVESTMENT_ACCOUNT_SUCCESS_MSG);
			}
		} catch (ServiceException e) {
			model.addObject(RequestMappingContstants.MODEL_ATTR_ERR, INVESTMENT_ACCOUNT_ERROR_MSG);
		}
		return model;
	}
}
