/**
 *
 */
package com.fil.crm.paas.quartz.jobs;

import org.json.JSONException;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.SimpleTrigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.stereotype.Component;

import com.fil.crm.paas.constants.QueryConstants;
import com.fil.crm.paas.dao.InvestmentAccountDAO;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.service.InvestmentAccountService;

/**
 * @author Arvind Singh
 *
 */
@Component
@DisallowConcurrentExecution
public class InvestmentAccountJob implements Job {

	private static final String SYSTEM = "SYSTEM";

	private static final Logger LOGGER = LoggerFactory.getLogger(InvestmentAccountJob.class);

	@Autowired
	private InvestmentAccountDAO investmentAccountDAO;

	@Autowired
	private InvestmentAccountService service;

	@Override
	public void execute(JobExecutionContext jobExecutionContext) {
		LOGGER.info("Running InvestmentAccountJob execute method..");
		try {
			service.pushInvestmentAccounts(SYSTEM);
		} catch (ServiceException | JSONException e) {
			LOGGER.error("Exception occured while executing the batch job InvestmentAccountJob", e);
		}
	}

	@Bean(name = "investmentAccountjobBean")
	public JobDetail sampleJob() {
		//return ConfigureQuartz.createJobDetail(this.getClass());
		return JobBuilder.newJob(InvestmentAccountJob.class).storeDurably(true).withIdentity("investmentAccountjobBean").build();
	}

	@Bean(name = "investmentAccountjobBeanTrigger")
	public CronTriggerFactoryBean sampleJobTrigger(@Qualifier("investmentAccountjobBean") JobDetail jobDetail) throws ServiceException {
		//call to CRDB to get cron expression value
		try {
			CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
			cronTriggerFactoryBean.setJobDetail(jobDetail);
			cronTriggerFactoryBean.setCronExpression(investmentAccountDAO.getConfigVar(QueryConstants.CRON_JOB_EXPRESSION));
			cronTriggerFactoryBean.setMisfireInstruction(SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
			return cronTriggerFactoryBean;
		} catch (DatabaseException e) {
			LOGGER.error("Some exception has occured while fetching cron job expression from CRDB." + e.getMessage());
			throw new ServiceException("database exception occured while fetching cron expression from crdb.", e);
		}
		//return ConfigureQuartz.createCronTrigger(jobDetail, cronExpression);
	}
}
