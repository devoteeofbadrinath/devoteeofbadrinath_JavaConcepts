package com.fil.crm.paas.invAcc.helper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.fil.crm.paas.enums.STATUS;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.helper.RestTemplateCaller;
import com.google.gson.JsonObject;

@RunWith(MockitoJUnitRunner.class)
public class RestTemplateCallerTest {

	@Mock
	RestTemplate restTemplate;

	@InjectMocks
	RestTemplateCaller restTemplateCaller;

	@Before
	public void init() {
	}

	@Test
	public void exchangeExceptionTest() throws Exception {
		JsonObject responseBody = new JsonObject();
		ResponseEntity < String > response = new ResponseEntity < String >(responseBody.toString(), HttpStatus.OK);
		Mockito.when(
				restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), Mockito.<Class < String >> any()))
				.thenThrow(new HttpStatusCodeException(HttpStatus.BAD_REQUEST, "Bad Request",
						new String("{\"message\":\"Token timed out\"}").getBytes(), null) {
				});
		boolean result = true;
		try {
			JsonObject actualResponseBody = restTemplateCaller.exchange("https://...", null);
		} catch (ServiceException ex) {
			result = false;
		}
		Assert.assertEquals(false, result);
	}

	@Test
	public void exchangeJSONExceptionTest() throws Exception {
		boolean result = true;
		STATUS exceptionStatus = STATUS.SUCCESS;
		ResponseEntity < String > response = new ResponseEntity < String >("Invalid JSON", HttpStatus.OK);
		Mockito.when(
				restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), Mockito.<Class < String >> any()))
				.thenReturn(response);
		try {
			JsonObject actualResponseBody = restTemplateCaller.exchange("https://...", null);
		} catch (ServiceException ex) {
			result = false;
			exceptionStatus = ex.getResult();
		}
		Assert.assertEquals(false, result);
		Assert.assertEquals(STATUS.INTERNAL_SERVER_ERROR, exceptionStatus);
	}

	@Test
	public void exchangeSuccessTest() throws Exception {
		JsonObject responseBody = new JsonObject();
		ResponseEntity < String > response = new ResponseEntity < String >(responseBody.toString(), HttpStatus.OK);
		Mockito.when(
				restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), Mockito.<Class < String >> any()))
				.thenReturn(response);
		JsonObject actualResponseBody = restTemplateCaller.exchange("https://...", null);
		System.err.println(actualResponseBody);
	}
}
