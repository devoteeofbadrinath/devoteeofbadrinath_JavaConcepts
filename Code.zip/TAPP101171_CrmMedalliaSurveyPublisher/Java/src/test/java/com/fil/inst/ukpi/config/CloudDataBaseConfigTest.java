package com.fil.inst.ukpi.config;


import static org.mockito.Mockito.lenient;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

@RunWith(MockitoJUnitRunner.class)
public class CloudDataBaseConfigTest {

	  @Autowired
	private CRDBDataSource cloudDataBaseConfig;

	@Mock
	private Environment env;

	@Test
	public void testDataSource() {
		try {
			lenient().when(env.getProperty("spring.datasource.driver-class-name")).thenReturn("oracle.jdbc.OracleDriver");
			lenient().when(env.getProperty("spring.datasource.url")).thenReturn("url");
			lenient().when(env.getProperty("spring_datasource_username")).thenReturn("username");
			lenient().when(env.getProperty("spring_datasource_password")).thenReturn("password");
			cloudDataBaseConfig.dataSource(env);
		} catch (Exception e) {
//			Assert.assertEquals("Driver oracle.jdbc.OracleDriver claims to not accept JDBC URL url", e.getMessage());
		}
	}
}
