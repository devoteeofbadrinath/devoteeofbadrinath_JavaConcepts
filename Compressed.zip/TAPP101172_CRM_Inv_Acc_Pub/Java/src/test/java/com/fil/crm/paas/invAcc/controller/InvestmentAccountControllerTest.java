package com.fil.crm.paas.invAcc.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fil.crm.paas.constants.JsonMappingConstants;
import com.fil.crm.paas.constants.RequestMappingContstants;
import com.fil.crm.paas.controller.InvestmentAccountController;
import com.fil.crm.paas.enums.STATUS;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.service.InvestmentAccountService;
import com.google.gson.JsonObject;

@RunWith(MockitoJUnitRunner.class)
public class InvestmentAccountControllerTest {

	@InjectMocks
	private InvestmentAccountController investmentAccountController;

	@Mock
	private InvestmentAccountService investmentAccountService;

	private MockMvc mockMvc;

	private User user;

	@Before
	public void init() {
		user = new User("invadmin", "fidelity", AuthorityUtils.createAuthorityList("ROLE_ADMIN"));
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(investmentAccountController).build();
	}

	private JsonObject getJsonObject() {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(JsonMappingConstants.CORRELATION_ID, "1234567");
		jsonObject.addProperty(JsonMappingConstants.STATUS, STATUS.SUCCESS.getMessage());
		return jsonObject;
	}

	@Test
	public void pushDCFundsToLayer7SuccessTest() throws Exception {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(JsonMappingConstants.CORRELATION_ID, "1234567");
		jsonObject.addProperty(JsonMappingConstants.STATUS, STATUS.SUCCESS.getMessage());
		TestingAuthenticationToken testingAuthenticationToken = new TestingAuthenticationToken(user, null);
		SecurityContextHolder.getContext().setAuthentication(testingAuthenticationToken);
		Mockito.when(investmentAccountService.pushInvestmentAccounts(Mockito.anyString())).thenReturn(jsonObject);
		mockMvc.perform(
				post(RequestMappingContstants.ROOT_API + RequestMappingContstants.PUSH_TO_LAYER7).principal(testingAuthenticationToken))
				.andExpect(status().isOk()).andExpect(model().attributeExists("msg"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void pushDCFundsToLayer7ServiceExceptionTest() throws Exception {
		TestingAuthenticationToken testingAuthenticationToken = new TestingAuthenticationToken(user, null);
		SecurityContextHolder.getContext().setAuthentication(testingAuthenticationToken);
		Mockito.when(investmentAccountService.pushInvestmentAccounts(Mockito.anyString())).thenThrow(ServiceException.class);
		mockMvc.perform(
				post(RequestMappingContstants.ROOT_API + RequestMappingContstants.PUSH_TO_LAYER7).principal(testingAuthenticationToken))
				.andExpect(model().attributeExists("error"));
	}

	@Test
	public void pushDCFundsToLayer7StatusFailTest() throws Exception {
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(JsonMappingConstants.CORRELATION_ID, "1234567");
		jsonObject.addProperty(JsonMappingConstants.STATUS, JsonMappingConstants.FAIL);
		TestingAuthenticationToken testingAuthenticationToken = new TestingAuthenticationToken(user, null);
		SecurityContextHolder.getContext().setAuthentication(testingAuthenticationToken);
		Mockito.when(investmentAccountService.pushInvestmentAccounts(Mockito.anyString())).thenReturn(jsonObject);
		mockMvc.perform(
				post(RequestMappingContstants.ROOT_API + RequestMappingContstants.PUSH_TO_LAYER7).principal(testingAuthenticationToken))
				.andExpect(model().attributeExists("error"));
	}
}
