package com.fil.inst.ukpi.serviceImp;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AuthEncodeDecode {

	@Value("${spring.security.user.name}")
	private String user;
	
	@Value("${spring.security.user.password}")
	private String pwd;
	
	@SuppressWarnings("unused")
	private final String getBasicAuthenticationHeader() {
	    String valueToEncode = user + ":" + pwd;
	    return "Basic " + Base64.getEncoder().encodeToString(valueToEncode.getBytes());
	}
	
	public final Boolean decoder(String authString) throws UnsupportedEncodingException {
		 String[] authParts = authString.split("\\s+");
	        String authInfo = authParts[1];
		String valueToEncode = user + ":" + pwd;
		byte[] authStringEnc = Base64.getDecoder().decode(authInfo);
		if(valueToEncode.equals(new String(authStringEnc,"utf-8").intern()))
			return true;
		
		return false;
	}
}
