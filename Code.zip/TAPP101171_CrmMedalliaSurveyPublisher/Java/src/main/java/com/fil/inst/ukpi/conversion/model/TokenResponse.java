package com.fil.inst.ukpi.conversion.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class TokenResponse {
	
	private String acccess_token;
	
	private String instance_url;
	
	private String id;
	
	private String token_type;
	
	private String issue_at;
	
	private String signature;

}
