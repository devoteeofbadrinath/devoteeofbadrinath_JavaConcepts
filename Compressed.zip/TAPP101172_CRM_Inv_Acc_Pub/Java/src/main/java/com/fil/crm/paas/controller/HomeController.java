package com.fil.crm.paas.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fil.crm.paas.constants.RequestMappingContstants;

@Controller
@RequestMapping(value = "/")
public class HomeController {

	/**
	 * On Authentication will take the User to the Admin page
	 *
	 * @param msg
	 *            Any message that is to be displayed on the page
	 * @param error
	 *            In case there's an error, 'true', 'false' otherwise
	 * @return the view name of the Admin Page
	 */
	@RequestMapping(value = RequestMappingContstants.ADMIN_URL, method = RequestMethod.GET)
	public ModelAndView adminPage(@ModelAttribute(RequestMappingContstants.MODEL_ATTR_MSG) String msg,
			@ModelAttribute(RequestMappingContstants.MODEL_ATTR_ERR) String error) {
		ModelAndView model = new ModelAndView();
		model.addObject(RequestMappingContstants.MODEL_ATTR_ERR, error);
		model.setViewName(RequestMappingContstants.ADMIN_VIEW);
		return model;
	}

	@RequestMapping(value = "")
	public String home() {
		return "healthCheck";
	}

	/**
	 * This method redirects the default calls to Login Form page.
	 *
	 * @param error
	 *            In case if there is problem while logging in, user name or
	 *            password incorrect
	 * @param logout
	 *            in case the user has logged out after logging in.
	 * @return the view name where the login form exists
	 */
	@RequestMapping(value = RequestMappingContstants.LOGIN, method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = RequestMappingContstants.MODEL_ATTR_ERR, required = false) String error,
			@RequestParam(value = RequestMappingContstants.LOGOUT, required = false) String logout) {
		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject(RequestMappingContstants.MODEL_ATTR_ERR, "Invalid username and password!");
		}
		if (logout != null) {
			model.addObject(RequestMappingContstants.MODEL_ATTR_MSG, "You've been logged out successfully.");
		}
		model.setViewName(RequestMappingContstants.LOGIN_VIEW);
		return model;
	}
}