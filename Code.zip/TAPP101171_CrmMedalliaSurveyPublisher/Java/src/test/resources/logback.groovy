/* 
 * The deployment pipeline will create the required environment variables for org/space/application
 * identification in PCF.
 * Therefore we check for the existence of one and the presence of that implies the others will
 * be available as well 
 */

def skipPatterns = "sun.reflect,java.lang.reflect,net.sf.cglib,ByCGLIB,org.springframework.aop"

if (System.getenv().containsKey("skipPatterns")) {
	skipPatterns = System.getenv("skipPatterns")
}

if (System.getenv("paasEnv") != null) {
	// Standard FIL PCF / application environment variables.
	def paasEnv = System.getenv("paasEnv")
	def orgName = System.getenv("orgName")
	def spaceName = System.getenv("spaceName")
	def appName = System.getenv("appName")
	def appId = System.getenv("appId")
    def flp_var=''
	if(spaceName!='PRD')
		flp_var='fil_uk_institutional_fidelityview_ap0001911_paas_np_' + spaceName
	else
		flp_var='fil_uk_institutional_fidelityview_ap0001911_paas_p_prd'
		
	appender("CONSOLE", ConsoleAppender) {
	  encoder(net.logstash.logback.encoder.LogstashEncoder) {
	   customFields = """{ "flp": "$flp_var","o":"$orgName","s":"$spaceName","a":"$appName"}"""
	  timestampPattern = 'yyyy-MM-dd HH:mm:ss.SSS'
      /*timeZone = 'BST'*/
	  fieldNames(net.logstash.logback.fieldnames.LogstashFieldNames) {
	     timestamp = 'd'
		  version = '[ignore]'
		  message = 'msg'
		  level='l'
		  thread='t'
	  }
	}
	}
	root(INFO, ["CONSOLE"])
	/*
	 * Switch on JMX configuration
	 */
	jmxConfigurator()
} else {
	appender("CONSOLE", ConsoleAppender) {
	def paasEnv = 'DEV'
	def flp='fil_uk_institutional_fidelityview_ap0001911_paas_np_' + paasEnv
	
	  encoder(net.logstash.logback.encoder.LogstashEncoder) {
	  customFields = """{ "flp": "$flp","s":"DEV","a":"supersedeAPI"}"""
	  timestampPattern = 'yyyy-MM-dd HH:mm:ss.SSS'
	  fieldNames(net.logstash.logback.fieldnames.LogstashFieldNames) {
	      timestamp = 'd'
		  version = '[ignore]'
		  message = 'msg'
		  level='l'
		  thread='t'
	  }
	  
	  }
	}
	
	root(INFO, ["CONSOLE"])

	/*
	 * Switch on JMX configuration
	 */
	jmxConfigurator()

}