package com.fil.crm.paas.helper;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fil.crm.paas.enums.STATUS;
import com.fil.crm.paas.exception.ServiceException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

/**
 * This class is a Helper class for making a REST call to an endpoint using
 * Spring RestTemplate
 * 
 * @author Arvind Singh
 */
@Component
public class RestTemplateCaller {

	private static final Logger LOGGER = LoggerFactory.getLogger(RestTemplateCaller.class);

	private String defaultExceptionMessage = " Some exception has occured while calling REST webservice.";

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * this method makes a REST POST call to the url and returns the JSON
	 * returned from the request
	 * 
	 * @param url
	 *            the endpoint to which the POST call is to be made
	 * @param entity
	 *            the entity / request with its body and headers
	 * @return the JSON Object returned from the request call
	 * @throws ServiceException
	 *             may throw {@link ServiceException} in case of REST call
	 *             timeout or mapping error
	 * @throws JSONException
	 */
	public JsonObject exchange(String url, HttpEntity < String > entity) throws ServiceException, JSONException {
		JsonObject result = null;
		LOGGER.info("URL  :" + url);
		if (null != url && !url.isEmpty()) {
			try {
				ResponseEntity < String > exchange = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
				result = getResponseObject(exchange.getBody());
			} catch (HttpStatusCodeException hse) {
				ErrorHelper.handleException(hse);
			} catch (JsonSyntaxException | RestClientException ex) {
				LOGGER.error("REST Template call error :: " + ex);
				throw new ServiceException(STATUS.INTERNAL_SERVER_ERROR, ex.getMessage(), ex);
			}
		}
		return result;
	}

	private static JsonObject getResponseObject(String jsonString) {
		Gson gson = new Gson();
		return gson.fromJson(jsonString, JsonObject.class);
	}
}