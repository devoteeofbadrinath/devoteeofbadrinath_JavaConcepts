package com.fil.inst.ukpi.sftp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FftsService {

	@Value("${ffts.host}")
	private String REMOTE_HOST;


	@Value("${ffts.user_name}")
	private String USERNAME;

	@Value("${ffts.port}")
	private int REMOTE_PORT;

	@Value("${fftsKey}")
	private String privatekey;
	
	@Value("${ffts.location}")
	private String remotePath;

	@Autowired
	ResourceLoader resourceLoader;


	public void fftsConnection(File file, String localFile) throws SftpException, IOException {

		log.info("ffts conection() starts");
		Session jschSession = null;
		
		try(FileInputStream fis = new FileInputStream(file)) {
			JSch jsch = new JSch();

			jsch.setKnownHosts(REMOTE_HOST);

			jschSession = jsch.getSession(USERNAME, REMOTE_HOST, REMOTE_PORT);
			jschSession.setConfig("StrictHostKeyChecking", "no");
			File resource = new ClassPathResource(privatekey).getFile();

			log.info("check ppk file location " + resource.getAbsolutePath() + " is exist " + resource.exists());
			jsch.addIdentity(resource.getAbsolutePath());

			jschSession.connect();
			Channel sftp = jschSession.openChannel("sftp");

			sftp.connect();
			log.info("connection created succssfully");
			ChannelSftp channelSftp = (ChannelSftp) sftp;
			channelSftp.cd(remotePath);

			log.info("transfer file to remote server triggered ");
			String fileLocation = file.getAbsolutePath();
			log.info("check file path and is exist before drop " + fileLocation + " is exist " + file.exists());
			channelSftp.put(fis, localFile);
			log.info("file uploaded to remote server ");

			channelSftp.exit();
			log.info("sftp connection terminated");

		} catch (JSchException e) {
			log.error("error during ffts");
			log.error(e.getMessage());;

		} finally {
			if (jschSession != null) {
				jschSession.disconnect();			

			}
		}

	}

	
}