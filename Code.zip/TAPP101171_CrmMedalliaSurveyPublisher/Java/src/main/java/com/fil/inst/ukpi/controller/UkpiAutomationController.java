package com.fil.inst.ukpi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fil.inst.ukpi.constants.CommonConstants;
import com.fil.inst.ukpi.serviceImp.AuthEncodeDecode;
import com.fil.inst.ukpi.serviceImp.FilesbyCreatedDate;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping(value = CommonConstants.UKPI)
@Slf4j
public class UkpiAutomationController {



	@Autowired
	private FilesbyCreatedDate filesbyCreatedDate;
	
	@Autowired
	private AuthEncodeDecode auth;

	// the format will be “yyyy-mm-dd” for createddate parameter.
	@PostMapping(value = CommonConsxtants.SALESFORCE)
	public ResponseEntity < String > getDatabyCreatedDate(@RequestParam(value = CommonConstants.MODIFIEd_DATE) 
	String createddate,@RequestHeader("authorization") String authString) throws Exception {
		log.info("controller for createddate is triggered");

		try {
			if(auth.decoder(authString)) {
			filesbyCreatedDate.getTokenFromSfByDate(createddate);
			return new ResponseEntity <>("Files are droped Successfully", HttpStatus.OK);
			}
			return new ResponseEntity <>("Authentication Error ", HttpStatus.NOT_FOUND); 
		} catch (Exception e) {			
			log.error(e.getMessage());
			return new ResponseEntity <>("Something went wrong", HttpStatus.NOT_FOUND);
		}

	}


}
