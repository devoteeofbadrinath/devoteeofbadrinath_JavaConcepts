package com.fil.inst.ukpi.scheduler;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SimpleTrigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.stereotype.Component;

import com.fil.inst.ukpi.constants.CommonConstants;
import com.fil.inst.ukpi.controller.AuthorisedToken;

import lombok.extern.slf4j.Slf4j;

@Component
@DisallowConcurrentExecution
@Slf4j
public class JobScheduler implements Job{
	

	@Autowired
	private AuthorisedToken authorisedToken;
	
	
	@Value("${max.retry}")
	private Integer maxtry; 
	
	@Value("${cron.expression}")
	private String cronExression;
	
	@Value("${count}")
	private int count;

	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		log.info("Job execution started");
		 JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		 
	        if(count >= maxtry){
	        	log.error("Retries exceeded");
	            JobExecutionException e = new JobExecutionException("Retries exceeded");
	            //make sure it doesn't run again
	            e.setUnscheduleAllTriggers(true);
	            log.error(e.getMessage());
	            count = 0;
	            throw e;
	        }
		try {
			
			authorisedToken.getTokenFromSf();
			
			dataMap.putAsString("count", 0);
		} catch(Exception e){
            count++;
            log.error("count of job retry execution "+ count);
            log.error("exception occured "+ e);
            dataMap.putAsString("count", count);
            JobExecutionException e2 = new JobExecutionException(e);

            try {
				Thread.sleep(CommonConstants.THREADSLEEP);
			} catch (InterruptedException e1) {
				log.error("InterruptedException occured "+e1.getMessage());
				 Thread.currentThread().interrupt();
			}

            e2.setRefireImmediately(true);
            throw e2;
        }
		
	}
	
	@Bean(name = "ukpiAutomation")
	public JobDetail vocUkpiJob() {
		return JobBuilder.newJob(JobScheduler.class).storeDurably(true).withIdentity("ukpiAutomation").build();
	}
	
	@Bean(name = "ukpiAutomationTrigger")
	public CronTriggerFactoryBean vocUkpiJobTrigger(@Qualifier("ukpiAutomation") JobDetail jobDetail) {
		CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
		cronTriggerFactoryBean.setJobDetail(jobDetail);
		cronTriggerFactoryBean.setCronExpression(cronExression);
		cronTriggerFactoryBean.setMisfireInstruction(SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
		return cronTriggerFactoryBean;
	
	}


}
