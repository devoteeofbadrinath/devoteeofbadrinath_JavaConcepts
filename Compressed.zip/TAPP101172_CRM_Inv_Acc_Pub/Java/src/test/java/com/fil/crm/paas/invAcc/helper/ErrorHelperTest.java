package com.fil.crm.paas.invAcc.helper;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.helper.ErrorHelper;

public class ErrorHelperTest {

	@Before
	public void init() {
	}

	//	@Test
	//	public void testConstructor() throws Exception {
	//		boolean result = true;
	//		Constructor < ErrorHelper > constructor = ErrorHelper.class.getDeclaredConstructor();
	//		assertTrue(Modifier.isPrivate(constructor.getModifiers()));
	//		constructor.setAccessible(true);
	//		try {
	//			constructor.newInstance();
	//		} catch (InvocationTargetException ex) {
	//			result = false;
	//		}
	//		Assert.assertEquals(false, result);
	//	}
	@Test
	public void testRestClientException() throws Exception {
		boolean result = true;
		try {
			ErrorHelper.handleException(new RestClientException("Error"));
		} catch (ServiceException ex) {
			result = false;
		}
		Assert.assertEquals(false, result);
		result = true;
		try {
			ErrorHelper.handleException(new HttpStatusCodeException(HttpStatus.BAD_REQUEST, "Bad Request",
					new String("{\"message\":\"Token timed out\"}").getBytes(), null) {
			});
		} catch (ServiceException ex) {
			result = false;
		}
		Assert.assertEquals(false, result);
	}

	@Test
	public void testRestClientExceptionWithoutBody() throws Exception {
		boolean result = true;
		try {
			ErrorHelper.handleException(new RestClientException("Error"));
		} catch (ServiceException ex) {
			result = false;
		}
		Assert.assertEquals(false, result);
		result = true;
		try {
			ErrorHelper.handleException(new HttpStatusCodeException(HttpStatus.BAD_REQUEST, "Bad Request") {
			});
		} catch (ServiceException ex) {
			result = false;
		}
		Assert.assertEquals(false, result);
	}
}