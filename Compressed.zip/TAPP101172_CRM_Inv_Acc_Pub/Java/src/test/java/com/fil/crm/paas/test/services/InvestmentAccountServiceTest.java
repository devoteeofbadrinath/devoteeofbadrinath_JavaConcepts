package com.fil.crm.paas.test.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.fil.crm.paas.dao.InvestmentAccountDAO;
import com.fil.crm.paas.domain.InvestmentAccount;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.helper.RestTemplateCaller;
import com.fil.crm.paas.service.InvestmentAccountService;
import com.google.gson.JsonObject;

/**
 * This is the Test Class for the FXRates Service Layer
 *
 * @author Arvind Singh
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class InvestmentAccountServiceTest {

	@InjectMocks
	private InvestmentAccountService investmentAccountService;

	@Mock
	private RestTemplateCaller restTemplateCaller;

	@Mock
	private InvestmentAccountDAO investmentAccountDAO;

	@SuppressWarnings({ "unchecked", "unused" })
	@Before
	public void setup() throws DatabaseException, ServiceException {
		//	ReflectionTestUtils.setField(investmentAccountService, "batchSize", 1);
		InvestmentAccount investmentAccount = new InvestmentAccount();
		investmentAccount.setCorrelationId("InvestmentAccount" + System.currentTimeMillis());
		investmentAccount.setCurrency("JPY");
		investmentAccount.setEffectiveDate("29-AUG-16");
		investmentAccount.setFundCode("000000000801817");
		investmentAccount.setFundValue("266679083710");
		investmentAccount.setSeqId("1");
		investmentAccount.setSourceType("InvestOne");
		java.util.List<InvestmentAccount> investmentAccountList = new ArrayList<InvestmentAccount>();
		investmentAccountList.add(investmentAccount);
		Mockito.when(investmentAccountDAO.getInvestmentAccounts(Mockito.anyInt(), Mockito.anyInt())).thenReturn(investmentAccountList);
		Mockito.when(investmentAccountDAO.getCount()).thenReturn(1L);
		Mockito.when(investmentAccountDAO.getConfigVar(Mockito.any())).thenReturn("1");
		Mockito.when(restTemplateCaller.exchange(Mockito.anyString(), Mockito.any(org.springframework.http.HttpEntity.class))).thenReturn(
				createJsonResponse());
	}

	private JsonObject createJsonResponse() {
		JsonObject jsonRes = new JsonObject();
		// sample Response created, Hard coded for now
		JsonObject obj = new JsonObject();
		obj.addProperty("STATUS", "SUCCESS");
		return obj;
	}

	@Test
	public void testPushInvestmentAccounts() throws ServiceException, DatabaseException {
		JsonObject jsonRes = investmentAccountService.pushInvestmentAccounts("TEST");
		assertTrue(null != jsonRes);
		assertTrue(jsonRes.has("STATUS"));
		assertEquals(jsonRes.get("STATUS").getAsString(), "SUCCESS");
	}

	@Test
	public void testPushInvestmentAccountsExcepton() throws Exception {
		Mockito.when(restTemplateCaller.exchange(Mockito.anyString(), Mockito.any(org.springframework.http.HttpEntity.class))).thenThrow(
				ServiceException.class);
		JsonObject jsonRes = investmentAccountService.pushInvestmentAccounts("TEST");
	}
}
