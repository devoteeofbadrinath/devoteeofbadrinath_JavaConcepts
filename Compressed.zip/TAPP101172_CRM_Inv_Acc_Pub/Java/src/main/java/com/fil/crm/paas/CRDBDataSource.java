package com.fil.crm.paas;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CRDBDataSource {

	private static final String CRDB_PASSWORD = "CRDB_PASSWORD";

	private static final String CRDB_USERNAME = "CRDB_USERNAME";

	@Value("${crdb.db.url}")
	private String url;

	@Value("${crdb.db.driverClass}")
	private String driver;

	@Bean(name = "dataSource")
	public DataSource crdbDataSource() {
		//username and password are set at fil paas
		String username = System.getenv(CRDB_USERNAME);
		String password = System.getenv(CRDB_PASSWORD);
		return DataSourceBuilder.create().username(username).password(password).url(url).driverClassName(driver).build();
	}
}