package com.fil.inst.ukpi.conversion.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SalesforceResponse {
	
	private String  SURVEY_TYPE;
	private String CONTACT_UNIQUE_ID;
	private String  ACCOUNT_ID;
	private String  CONTACT_FIRST_NAME;
	private String CONTACT_SURNAME;
	private String CONTACT_EMAIL;
	private String CONTACT_PHONE;
	private String CONTACT_INFLUENCE_LEVEL;
	private String UNIQUE_TRANSACTION_ID;
	private String CONTACT_LOCALE;
	private String CONTACT_WAVE;
	private String CONTACT_BUSINESS_CHANNEL;
	private String CONTACT_BUSINESS_SUB_CHANNEL;
	private String CONTACT_BUSINESS_SEGMENT;
	private String GLOBAL_ACCOUNT_INDICATOR;
	private String ACCOUNT_TIER;
	private String SALES_AND_RM_NAME;
	private String SECONDARY_CONTACT;
	private String CONTACT_AND_ALERT_OWNER_NAME;
	private String CONTACT_AND_ALERT_OWNER_EMAIL;
	private String ACCOUNT_TENURE;
	private String AGE;
	private String TRANSACTION_CHANNEL;
	private String CLIENT_COUNTRY;
	private String ACTIVE;
	private String SAM_LOGIC;
	private String TRANSACTION_TYPE;
	private String MEETING_TYPE;
	private String SCHEME_CODE;
	private String SCHEME_NAME;
	private String SALUTATION;
	private String TITLE;
	private String KEY_ACCOUNT;
	private String ESCALATION_OWNER_NAME;
	private String ESCALATION_OWNER_EMAIL;
	private String VO_NAME;
	private String VO_NUMBER;
	private String VOE_1_NAME;
	private String VOE_1_NUMBER;
	private String VOE_2_NAME;
	private String VOE_2_NUMBER;
	private String NETWORK;
	private String CONTACT_JOB_TITLE;
	private String REPORT_TYPE;
	private String  OPERATIONAL_CONTACT;
	private String  KEY_NPS_CONTACT;
	private String  LAST_CONTACT;
	private String  MARKETING_PREFERENCE;
	private String  TNPS_TRANSACTION_CONTACT;
	private String  PRODUCT;
	private String  COMMS_CONTACT;
	private String TNPS_TRANSACTION_CONTACT_FULL_NAME;
	private String FIL_ENTITY;
	private String INTERACTION_LENGTH;
	private String 	CALL_WAIT;
	private String 	TNPS_CONTACT_DISC;
	private String 	THIRD_PARTY;
	private String 	GENDER;
	private String 	WEB_USAGE;
	private String 	ASSETS;
	private String 	GROUP_ASSETS;
	private String 	TEAM_NAME;
	private String 	EMPLOYEE_NUMBER;
	private String 	COMPLAINT_OUTCOME;
	private String 	COMPLAINT_REDRESS;
	private String 	INITIATION_CHANNEL;
	private String 	CLOSING_CHANNEL;
	private String 	SECONDARY_CONTACT_EMAIL;
	private String 	STOCK_PLAN_SERVICES;
	private String 	FIDELITY_RETIREMENT_SERVICES;
	private String 	DIGITAL_WEALTH;
	private String 	INVEST_AT_WORK;
	private String 	EI_AND_WI;
	private String 	CANADA_CET;
	

}
