package com.fil.crm.paas.exception;

import java.util.List;

import org.springframework.validation.ObjectError;

import com.fil.crm.paas.enums.STATUS;

/**
 * This class will serve as the Exception class for any kind of Service level
 * exceptions thrown in the Service layer of the application.
 *
 * @author Arvind Singh
 */
public class ServiceException extends BaseException {

	/**
	 * 
	 */
	private STATUS result;

	private List < ObjectError > objectErrors;

	public ServiceException(STATUS result, List < ObjectError > objectErrors) {
		super();
		this.result = result;
		this.objectErrors = objectErrors;
	}

	public STATUS getResult() {
		return result;
	}

	public void setResult(STATUS result) {
		this.result = result;
	}

	public List < ObjectError > getObjectErrors() {
		return objectErrors;
	}

	public void setObjectErrors(List < ObjectError > objectErrors) {
		this.objectErrors = objectErrors;
	}

	public ServiceException() {
		super("Some Service Exception occurred in the App ", null);
	}

	public ServiceException(STATUS result) {
		this.result = result;
	}

	public ServiceException(STATUS result, String message, Throwable e) {
		super(message, e, null);
		this.result = result;
	}

	public ServiceException(STATUS result, String message, Throwable e, String trackingId) {
		super(message, e, trackingId);
		this.result = result;
	}

	public ServiceException(STATUS result, Throwable e) {
		super(null, e, null);
		this.result = result;
	}

	public ServiceException(String message, Throwable throwable) {
		super(message, throwable);
		super.setMessage(message);
	}
}