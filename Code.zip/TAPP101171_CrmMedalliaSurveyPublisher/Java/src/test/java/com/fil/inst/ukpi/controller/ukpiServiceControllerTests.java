package com.fil.inst.ukpi.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ukpiServiceControllerTests {

	

	@InjectMocks
	private UkpiAutomationController processorServiceController;
	


	@Test
	public void testProcessorServiceDaily() throws Exception {
		processorServiceController.getDatabyCreatedDate("2023-09-09","basic auth");
		Assert.assertNotNull(processorServiceController);
	}

	
}
