package com.fil.crm.paas.helper;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fil.crm.paas.dao.InvestmentAccountDAO;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.vo.EmailConfig;

@Service
public class EmailHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailHelper.class);

	@Autowired
	private InvestmentAccountDAO investmentAccountDAO;

	@Value("${fil.pass.email.source.system}")
	private String SOURCE_SYSTEM;

	@Value("${fil.pass.email.destination.system}")
	private String DESTINATION_SYSTEM;

	@Value("${spring.profiles.active}")
	private String ENVIRONMENT;

	private String EMAIL_SOURCE = "FIL PAAS";

	private String SUBJECT_TEST_PREFIX = "TEST EMAIL - ";

	private String SUBJECT_FONT_PREFIX = "<div style='font-family:Courier New;'>";

	private String BODY_TEST_PREFIX = "-------------------------------------------------------------------------------------</BR><h2 style='color:red;'>This is a TEST EMAIL. Please ignore.</h2>-------------------------------------------------------------------------------------</BR> ";

	/**
	 * This method will send email
	 *
	 * @param correlationId
	 * @param errorReason
	 */
	public void sendEmail(String correlationId, String errorReason) {
		String emailText = "An error occurred while transmitting data between systems. Following are the details, </BR></BR> Error Details </BR><TABLE  style='font-family:Courier New;'><TR><TD> CorrelationId</TD><TD> : <B>"
				+ correlationId + "</B></TD><TR><TD  style='vertical-align:top;'>Error Message</TD><TD> : <B>" + errorReason
				+ "</B></TD></TR></BR><TR><TD>Source System</TD><TD>: <B>" + SOURCE_SYSTEM
				+ "</B></TD></TR><TR><TD>Destination System</TD><TD>: <B>" + DESTINATION_SYSTEM
				+ "</B></TD></TR><TR><TD>Email Source</TD><TD>: <B>" + EMAIL_SOURCE + "<B/></TD></TR><TR><TD>Environment</TD><TD>: <B>"
				+ ENVIRONMENT + "</B></TD></TR></TABLE></div>";
		Properties props = new Properties();
		try {
			EmailConfig emailConfigVars = fetchEmailConfiguration();
			props.put(emailConfigVars.getEmailHost(), emailConfigVars.getEmailServer());
			Session session = Session.getInstance(props);
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(emailConfigVars.getFromEmailAddress()));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailConfigVars.getToEmailAddress()));
			if (!ENVIRONMENT.equalsIgnoreCase("prod")) {
				emailText = SUBJECT_FONT_PREFIX + BODY_TEST_PREFIX + emailText;
				message.setSubject(SUBJECT_TEST_PREFIX + emailConfigVars.getSubject());
			} else {
				emailText = SUBJECT_FONT_PREFIX + emailText;
				message.setSubject(emailConfigVars.getSubject());
			}
			message.setContent(emailText, "text/html; charset=utf-8");
			Transport.send(message);
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * To fetch email dynamic properties
	 *
	 * @return email
	 */
	private EmailConfig fetchEmailConfiguration() {
		EmailConfig emailConfigVars = null;
		try {
			emailConfigVars = investmentAccountDAO.getEmailConfig();
		} catch (DatabaseException e) {
			LOGGER.error("Some exception has occured while fetching email config data from CRDB." + e.getMessage());
		}
		return emailConfigVars;
	}
}
