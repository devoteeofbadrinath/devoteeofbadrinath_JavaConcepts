package com.fil.crm.paas.service;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.quartz.DisallowConcurrentExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.fil.crm.paas.constants.JsonMappingConstants;
import com.fil.crm.paas.constants.QueryConstants;
import com.fil.crm.paas.dao.InvestmentAccountDAO;
import com.fil.crm.paas.domain.AuditData;
import com.fil.crm.paas.domain.InvestmentAccount;
import com.fil.crm.paas.exception.DatabaseException;
import com.fil.crm.paas.exception.ServiceException;
import com.fil.crm.paas.helper.EmailHelper;
import com.fil.crm.paas.helper.RestTemplateCaller;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * This is the service class for fetching investment accounts from crdb and
 * pushing them to layer7
 *
 * @author Arvind Singh
 *
 */
@Service("investmentAccountService")
@DisallowConcurrentExecution
public class InvestmentAccountService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvestmentAccountService.class);

	private static final String INVESTMENT_ACCOUNT = "InvestmentAccount";

	private static final String AUTHORIZATION = "Authorization";

	@Value("${paas.authorization}")
	private String paasAuth;

	@Autowired
	private EmailHelper emailHelper;

	@Autowired
	private InvestmentAccountDAO investmentAccountDAO;

	@Autowired
	private RestTemplateCaller restTemplateCaller;

	@Value("${response.attrib.status}")
	private String STATUS;

	@Value("${response.attrib.timetaken}")
	private String TIME_TAKEN;

	@Value("${fil.paas.layer7.token}")
	private String TOKEN_LAYER7;

	@Value("${inbound.url}")
	private String URL;

	/**
	 * This method will do the following: 1. Fetch the investment account data
	 * from CRDB 2. push the investment account data to Layer7
	 *
	 * @param sfObjects
	 * @return
	 * @throws ServiceException
	 * @throws JSONException
	 * @throws DatabaseException
	 */
	public JsonObject pushInvestmentAccounts(String userName) throws ServiceException, JSONException {
		LOGGER.info("InvestmentAccountService :: pushInvestmentAccounts( ) --- START");
		AuditData auditData = new AuditData();
		String correlationId = INVESTMENT_ACCOUNT + System.currentTimeMillis();
		JsonObject responseJson = new JsonObject();
		long startTime = System.currentTimeMillis();
		auditData.setStartTime(startTime);
		responseJson = createBatches(responseJson, correlationId, auditData);
		long endTime = System.currentTimeMillis();
		LOGGER.info("Time taken :: " + (endTime - startTime));
		//Adding below properties for Auditing
		responseJson.addProperty(JsonMappingConstants.START_TIME, startTime);
		responseJson.addProperty(JsonMappingConstants.END_TIME, endTime);
		responseJson.addProperty(JsonMappingConstants.USERNAME, userName);
		LOGGER.info("InvestmentAccountService :: pushInvestmentAccounts( ) --- END");
		return responseJson;
	}

	/**
	 * This private method will audit the exception scenario
	 *
	 * @param correlationId
	 * @param e
	 */
	private void auditException(String correlationId, Exception e, AuditData auditData) {
		auditData.setEndTime(System.currentTimeMillis());
		auditData.setStatus(JsonMappingConstants.FAIL);
		auditData.setCorrelationId(correlationId);
		auditData.setErrorReason("ExceptionCause - " + e.getCause() + "****-**** ExceptionMessage -" + e.getMessage());
		investmentAccountDAO.saveAudit(auditData);
		//	Send email with error notification
		try {
			String sendEmailEnabled = investmentAccountDAO.getConfigVar(QueryConstants.EMAIL_ENABLE);
			if (JsonMappingConstants.TRUE.equalsIgnoreCase(sendEmailEnabled)) {
				emailHelper.sendEmail(correlationId, e.getMessage());
			}
		} catch (Exception ex) {
			LOGGER.error("Exception occured while sending error email notification", ex);
		}
	}

	/**
	 * This method will create the batches and send them for processing
	 *
	 * @param responseJson
	 * @return JsonObject
	 * @throws JSONException
	 * @throws DatabaseException
	 */
	private JsonObject createBatches(JsonObject responseJson, String correlationId, AuditData auditData)
			throws ServiceException, JSONException {
		try {
			Long numberOfRecords = investmentAccountDAO.getCount();
			int batchSize = Integer.valueOf(investmentAccountDAO.getConfigVar(QueryConstants.BATCH_SIZE));
			int offset = 0;
			int batchNum = 0;
			int limit = 0;
			while (numberOfRecords > 0) {
				offset = batchNum * batchSize + 1;
				limit = offset + batchSize - 1;
				responseJson = processRecords(offset, limit, correlationId, auditData);
				batchNum++;
				numberOfRecords -= batchSize;
			}
		} catch (NumberFormatException | DatabaseException e) {
			throw new ServiceException("Some service exception has occured :: InvestmentAccountService :: createBatches() ", e);
		}
		return responseJson;
	}

	/**
	 * This is private method to create the HttpEntity for layer7 web service
	 * call
	 *
	 * @param JsonObject
	 *            - This is the request payload
	 *
	 * @return HttpEntity<String> - Http Entity for WS call to layer7
	 */
	private HttpEntity < String > createRequestEntityFromRequest(JsonObject obj) {
		// headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		List < MediaType > accept = new ArrayList < MediaType >();
		accept.add(MediaType.APPLICATION_JSON);
		headers.setAccept(accept);
		headers.add("token", TOKEN_LAYER7);
		headers.add(AUTHORIZATION, paasAuth); // Adding paasAuth token for basic authentication on Layer7
		// header + request body
		HttpEntity < String > reqEntity = new HttpEntity < String >(obj.toString(), headers);
		return reqEntity;
	}

	/**
	 * This method will create the json request for webservice call
	 *
	 * @param getInvestmentAccounts
	 * @param correlationId
	 * @return JsonObject - json request
	 */
	private JsonObject createRequestJson(List < InvestmentAccount > getInvestmentAccounts, String correlationId) {
		JsonObject requestJson = new JsonObject();
		requestJson.addProperty(JsonMappingConstants.DATA_SET_NAME, JsonMappingConstants.DATA_SET_NAME_VALUE);
		requestJson.addProperty(JsonMappingConstants.CORRELATION_ID, correlationId);
		//Data array - payload for Investment accounts
		JsonArray arr = new JsonArray();
		for (InvestmentAccount investmenatAccount : getInvestmentAccounts) {
			JsonObject json = new JsonObject();
			json.addProperty(JsonMappingConstants.IDENTIFIER, investmenatAccount.getFundCode());
			json.addProperty(JsonMappingConstants.IDENTIFIER_TYPE, investmenatAccount.getSourceType());
			json.addProperty(JsonMappingConstants.AUM, investmenatAccount.getFundValue());
			json.addProperty(JsonMappingConstants.AUM_ISO_CURRENCY_CODE, investmenatAccount.getCurrency());
			json.addProperty(JsonMappingConstants.AUM_AS_AT_DATE, investmenatAccount.getEffectiveDate());
			//			json.addProperty(JsonMappingConstants.ACCOUNT_STATUS, investmenatAccount.getAccountStatus());
			//			json.addProperty(JsonMappingConstants.ACCOUNT_INFO, investmenatAccount.getAccountInfo());
			arr.add(json);
		}
		requestJson.add(JsonMappingConstants.DATA, arr);
		return requestJson;
	}

	/**
	 * This method will process the batch records
	 *
	 * @param offset
	 *            - starting record number
	 * @param limit
	 *            - last record to fetch in the batch
	 * @return
	 * @throws JSONException
	 * @throws DatabaseException
	 */
	private JsonObject processRecords(int offset, int limit, String correlationId, AuditData auditData) throws JSONException {
		JsonObject responseJson = new JsonObject();
		try {
			List < InvestmentAccount > getInvestmentAccounts = investmentAccountDAO.getInvestmentAccounts(offset, limit);
			responseJson.addProperty(JsonMappingConstants.STATUS, JsonMappingConstants.SUCCESS);
			JsonObject requestJson = createRequestJson(getInvestmentAccounts, correlationId);
			HttpEntity < String > entity = createRequestEntityFromRequest(requestJson);
			responseJson = restTemplateCaller.exchange(URL, entity);
		} catch (ServiceException | DatabaseException e) {
			auditException(correlationId, e, auditData);
			responseJson.addProperty(JsonMappingConstants.STATUS, JsonMappingConstants.FAIL);
		} finally {
			responseJson.addProperty(JsonMappingConstants.CORRELATION_ID, correlationId);
		}
		LOGGER.info("InboundIntegrationService :: processRecords( ) -> response From Layer 7 : " + responseJson.toString());
		return responseJson;
	}
}